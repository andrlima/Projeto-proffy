const proffys = [
    { name: "Claudenizio Dias Alves Filho",
      avatar: "https://avatars2.githubusercontent.com/u/69214919?s=460&u=d4c0303295fb765ba65c0818cf01456b650e21b9&v=4",
      whatsapp: 99123456789,
      bio: "Desenvolvedor de programação mais famoso do Brasil, com cerca de 500.000 pessoas já se formaram no mundo todo.", subject: "Tecnologia",
      cost: "500", 
      weekday: [1] , 
      time_from: [1200], 
      time_to: [1800]
    },
    { name: "Diego Fernandes",
      avatar: "https://avatars2.githubusercontent.com/u/2254731?s=460&amp;u=0ba16a79456c2f250e7579cb388fa18c5c2d7d65&amp;v=4",
      whatsapp: 99999999999,
      bio: "Entusiasta das melhores tecnologias de química avançada. Apaixonado por explodir coisas em laboratório e por mudar a vida das pessoas através de experiências. Mais de 200.000 pessoas já passaram por uma das minhas explosões.", subject: "Química",
      cost: "250", 
      weekday: [2] , 
      time_from: [830], 
      time_to: [1230]
    },
    { name: "Mayk Brito",
      avatar: "https://avatars2.githubusercontent.com/u/6643122?s=460&u=1e9e1f04b76fb5374e6a041f5e41dce83f3b5d92&v=4",
      whatsapp: 99999999999,
      bio: "Instrutor de Educação Física para iniciantes, minha missão de vida é levar saúde e contribuir para o crescimento de quem se interessar. Comecei a minha jornada profissional em 2001, quando meu pai me deu dois alteres de 32kg com a seguinte condição: Aprenda a fazer dinheiro com isso!", subject: "Educação Física",
      cost: "150", 
      weekday: [2] , 
      time_from: [830], 
      time_to: [1230]
    }
]